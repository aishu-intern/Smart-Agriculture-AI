import pandas as pd
import numpy as np
import streamlit as st
from sklearn.ensemble import RandomForestClassifier

# Page setup
st.set_page_config(page_title="Smart Farming AI", layout="wide")

st.title("🌿 Smart Farming Assistant")
st.write("Get Crop Suggestion + Profit + Risk Analysis")

# Load dataset
@st.cache_data
def load_data():
    return pd.read_csv("Crop_recommendation.csv")

try:
    data = load_data()
except:
    st.error("Dataset missing! Upload Crop_recommendation.csv")
    st.stop()

# Model training
X = data.drop("label", axis=1)
y = data["label"]

model = RandomForestClassifier(n_estimators=150, random_state=42)
model.fit(X, y)

# Extra feature (NEW)
soil_type = st.selectbox("Soil Type", ["Loamy", "Sandy", "Clay", "Black", "Red"])

# Inputs
col1, col2 = st.columns(2)

with col1:
    N = st.slider("Nitrogen", 0, 150, 40)
    P = st.slider("Phosphorus", 0, 150, 40)
    K = st.slider("Potassium", 0, 150, 40)

with col2:
    temperature = st.slider("Temperature", 0.0, 50.0, 26.0)
    humidity = st.slider("Humidity", 0.0, 100.0, 65.0)
    ph = st.slider("Soil pH", 0.0, 14.0, 6.5)
    rainfall = st.slider("Rainfall", 0.0, 300.0, 120.0)

# Fertilizer suggestion (NEW)
def suggest_fertilizer(N, P, K):
    if N < 40:
        return "Add Nitrogen-rich fertilizer (Urea)"
    elif P < 40:
        return "Use Phosphate fertilizer (DAP)"
    elif K < 40:
        return "Add Potassium fertilizer (MOP)"
    else:
        return "NPK levels are balanced"

# Profit model (UPDATED)
def calculate_profit(crop):
    base_prices = {
        "rice": 22, "maize": 20, "cotton": 65,
        "sugarcane": 4, "wheat": 25
    }

    base_yield = {
        "rice": 2400, "maize": 2100, "cotton": 900,
        "sugarcane": 38000, "wheat": 2300
    }

    if crop in base_prices:
        # add random fluctuation → UNIQUE OUTPUT
        variation = np.random.uniform(0.9, 1.2)
        return int(base_prices[crop] * base_yield[crop] * variation)
    else:
        return int(np.random.uniform(30000, 80000))

# Risk analysis (NEW)
def risk_level(rainfall, temperature):
    if rainfall < 50 or temperature > 40:
        return "High Risk ⚠️"
    elif rainfall < 100:
        return "Medium Risk ⚡"
    else:
        return "Low Risk ✅"

# Button
if st.button("🚀 Get Recommendation"):

    input_data = np.array([[N, P, K, temperature, humidity, ph, rainfall]])

    prediction = model.predict(input_data)[0]
    confidence = np.max(model.predict_proba(input_data)) * 100

    st.success(f"🌾 Suggested Crop: {prediction}")
    st.write(f"🔍 Confidence Level: {confidence:.2f}%")

    # Profit
    profit = calculate_profit(prediction)
    st.info(f"💰 Expected Profit: ₹{profit} per acre")

    # Risk
    risk = risk_level(rainfall, temperature)
    st.warning(f"🌦 Risk Level: {risk}")

    # Fertilizer
    fert = suggest_fertilizer(N, P, K)
    st.write(f"🧪 Fertilizer Advice: {fert}")

    # Soil note (NEW)
    st.write(f"🌱 Selected Soil Type: {soil_type}")

    # Graph (different style)
    sample_crops = ["rice", "maize", "wheat", "cotton"]
    values = [calculate_profit(c) for c in sample_crops]

    chart_data = pd.DataFrame({
        "Crop": sample_crops,
        "Profit": values
    }).set_index("Crop")

    st.subheader("📈 Profit Comparison")
    st.line_chart(chart_data)